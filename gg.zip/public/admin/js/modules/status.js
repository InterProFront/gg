'use strict';

var Model = (function () {
    var $this;
    return {
        init : function () {
            $this = this;
        },
        data : function () {
        },
        clear: function () {
        },
        get  : function (options) {
        },
        set  : function (options) {
        }
    }


})();

//module.exports = Model;